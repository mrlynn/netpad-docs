# Live Form Preview Component

## Technical Specification

**Version:** 1.0.0  
**Status:** Draft  
**Author:** Michael  
**Target:** Docusaurus documentation site (docs.netpad.io)

---

## 1. Overview

### 1.1 Purpose

The Live Form Preview component allows documentation readers to see actual NetPad form rendering directly within docs pages. Instead of static screenshots or descriptions, users interact with real form fields, see validation in action, and understand NetPad's capabilities through hands-on experience.

### 1.2 Goals

| Goal | Description | Success Metric |
|------|-------------|----------------|
| **Demonstrate, don't describe** | Show form capabilities live instead of explaining them | User understands field type in <10 seconds |
| **Zero friction** | No login, no setup, works instantly in docs | 100% client-side, no API calls required |
| **Accurate representation** | Renders identically to production NetPad forms | Visual parity with cloud platform |
| **Developer utility** | Readers can copy config and use it | Export config button, copy-to-clipboard |

### 1.3 Non-Goals (v1)

- Full form builder functionality (this is preview only, not editing)
- Form submission to real endpoints
- Workflow integration preview
- Conversational form mode (future v2)
- Server-side rendering of forms

---

## 2. User Experience

### 2.1 Usage Contexts

The component will be used in several documentation contexts:

| Context | Example | Form Complexity |
|---------|---------|-----------------|
| **Field type reference** | "Here's what a `rating` field looks like" | Single field |
| **Feature demonstrations** | "Conditional logic hides fields based on input" | 3-5 fields with logic |
| **Template previews** | "The IT Help Desk template includes these fields" | Full form (10-20 fields) |
| **Tutorial walkthroughs** | "Build this form step by step" | Progressive reveal |

### 2.2 User Interactions

Users should be able to:

1. **View** — See the rendered form with all styling
2. **Interact** — Fill in fields, trigger validation, see conditional logic
3. **Inspect** — Toggle to view the underlying JSON/TypeScript config
4. **Copy** — Export the configuration for use in their own projects
5. **Reset** — Clear all entered data and start fresh
6. **Resize** — See responsive behavior (mobile/tablet/desktop)

### 2.3 Wireframe

```
┌─────────────────────────────────────────────────────────────────┐
│  ┌─────────────────────────────────────────────────────────┐    │
│  │ [Preview] [Config]                    [Mobile ▼] [Reset]│    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                                                         │    │
│  │   ┌─────────────────────────────────────────────────┐   │    │
│  │   │  Your Name *                                    │   │    │
│  │   │  ┌─────────────────────────────────────────┐    │   │    │
│  │   │  │ John Smith                              │    │   │    │
│  │   │  └─────────────────────────────────────────┘    │   │    │
│  │   │                                                 │   │    │
│  │   │  Email *                                        │   │    │
│  │   │  ┌─────────────────────────────────────────┐    │   │    │
│  │   │  │ john@example.com                        │    │   │    │
│  │   │  └─────────────────────────────────────────┘    │   │    │
│  │   │                                                 │   │    │
│  │   │  Department                                     │   │    │
│  │   │  ┌─────────────────────────────────────────┐    │   │    │
│  │   │  │ Engineering                           ▼ │    │   │    │
│  │   │  └─────────────────────────────────────────┘    │   │    │
│  │   │                                                 │   │    │
│  │   │            ┌──────────────────┐                 │   │    │
│  │   │            │     Submit       │                 │   │    │
│  │   │            └──────────────────┘                 │   │    │
│  │   │                                                 │   │    │
│  │   └─────────────────────────────────────────────────┘   │    │
│  │                                                         │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │ ✓ Try entering an invalid email to see validation       │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

**Config View (toggled):**

```
┌─────────────────────────────────────────────────────────────────┐
│  ┌─────────────────────────────────────────────────────────┐    │
│  │ [Preview] [Config]                [TypeScript ▼] [Copy] │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │ ```typescript                                           │    │
│  │ const formConfig: FormConfig = {                        │    │
│  │   fields: [                                             │    │
│  │     {                                                   │    │
│  │       type: 'short_text',                               │    │
│  │       path: 'name',                                     │    │
│  │       label: 'Your Name',                               │    │
│  │       required: true,                                   │    │
│  │     },                                                  │    │
│  │     {                                                   │    │
│  │       type: 'email',                                    │    │
│  │       path: 'email',                                    │    │
│  │       label: 'Email',                                   │    │
│  │       required: true,                                   │    │
│  │     },                                                  │    │
│  │     ...                                                 │    │
│  │   ]                                                     │    │
│  │ };                                                      │    │
│  │ ```                                                     │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Component API

### 3.1 Basic Usage

```jsx
import { FormPreview } from '@site/components/FormPreview';

<FormPreview
  fields={[
    { type: 'short_text', path: 'name', label: 'Your Name', required: true },
    { type: 'email', path: 'email', label: 'Email', required: true },
  ]}
/>
```

### 3.2 Full Props Interface

```typescript
interface FormPreviewProps {
  // === FORM CONFIGURATION ===
  
  /** Array of field configurations */
  fields: FieldConfig[];
  
  /** Optional: Load a pre-built template by ID */
  template?: string;  // e.g., 'contact-form', 'lead-capture'
  
  /** Form-level settings */
  settings?: {
    submitButtonText?: string;
    showSubmitButton?: boolean;
    layout?: 'single-column' | 'two-column';
  };
  
  /** Theme overrides */
  theme?: {
    mode?: 'light' | 'dark' | 'auto';
    primaryColor?: string;
    borderRadius?: 'none' | 'sm' | 'md' | 'lg';
  };
  
  /** Conditional logic rules */
  conditionalLogic?: ConditionalRule[];
  
  /** Computed field definitions */
  computedFields?: ComputedFieldConfig[];
  
  // === PREVIEW BEHAVIOR ===
  
  /** Initial values to pre-fill */
  initialValues?: Record<string, any>;
  
  /** Default viewport for responsive preview */
  defaultViewport?: 'mobile' | 'tablet' | 'desktop';
  
  /** Allow viewport switching */
  showViewportSwitcher?: boolean;  // default: true
  
  /** Show the config toggle tab */
  showConfigTab?: boolean;  // default: true
  
  /** Config export format options */
  configFormats?: ('typescript' | 'json')[];  // default: ['typescript', 'json']
  
  /** Show reset button */
  showReset?: boolean;  // default: true
  
  /** Instructional hint shown below form */
  hint?: string;
  
  /** Height constraint */
  height?: number | 'auto';  // default: 'auto', max 600px
  
  // === CALLBACKS ===
  
  /** Called when form values change */
  onValuesChange?: (values: Record<string, any>) => void;
  
  /** Called when validation state changes */
  onValidationChange?: (isValid: boolean, errors: ValidationError[]) => void;
  
  /** Called when user copies config */
  onConfigCopy?: (format: string, config: string) => void;
}
```

### 3.3 Field Configuration Type

Should align exactly with NetPad's existing `FieldConfig` type:

```typescript
interface FieldConfig {
  // Required
  type: FieldType;  // 'short_text' | 'email' | 'dropdown' | ... (30+ types)
  path: string;     // unique identifier, maps to document path
  label: string;    // display label
  
  // Common optional
  required?: boolean;
  placeholder?: string;
  helpText?: string;
  defaultValue?: any;
  disabled?: boolean;
  hidden?: boolean;
  width?: 'full' | 'half' | 'third' | 'quarter';
  
  // Validation
  validation?: {
    minLength?: number;
    maxLength?: number;
    min?: number;
    max?: number;
    pattern?: string;
    customMessage?: string;
  };
  
  // Type-specific
  options?: { label: string; value: string }[];  // for dropdown, radio, checkbox
  rows?: number;  // for long_text
  accept?: string[];  // for file_upload
  // ... etc for each field type
}
```

### 3.4 Usage Examples

**Single field demonstration:**

```jsx
// In docs/fields/rating.mdx
<FormPreview
  fields={[
    { 
      type: 'rating', 
      path: 'satisfaction', 
      label: 'How satisfied are you?',
      maxRating: 5,
      icon: 'star'
    }
  ]}
  showConfigTab={true}
  hint="Click the stars to rate"
/>
```

**Conditional logic demonstration:**

```jsx
// In docs/features/conditional-logic.mdx
<FormPreview
  fields={[
    { type: 'dropdown', path: 'contactMethod', label: 'Preferred Contact Method', 
      options: [
        { label: 'Email', value: 'email' },
        { label: 'Phone', value: 'phone' }
      ]
    },
    { type: 'email', path: 'email', label: 'Email Address' },
    { type: 'phone', path: 'phone', label: 'Phone Number' },
  ]}
  conditionalLogic={[
    { 
      action: 'show', 
      targetField: 'email',
      conditions: [{ field: 'contactMethod', operator: 'equals', value: 'email' }]
    },
    { 
      action: 'show', 
      targetField: 'phone',
      conditions: [{ field: 'contactMethod', operator: 'equals', value: 'phone' }]
    },
  ]}
  hint="Select a contact method to see conditional fields appear"
/>
```

**Full template preview:**

```jsx
// In docs/templates/it-helpdesk.mdx
<FormPreview
  template="it-helpdesk"
  defaultViewport="desktop"
  height={500}
  hint="This is the complete IT Help Desk template with all fields"
/>
```

**Computed fields demonstration:**

```jsx
// In docs/features/computed-fields.mdx
<FormPreview
  fields={[
    { type: 'number', path: 'quantity', label: 'Quantity', defaultValue: 1 },
    { type: 'currency', path: 'unitPrice', label: 'Unit Price', defaultValue: 29.99 },
    { type: 'number', path: 'discount', label: 'Discount %', defaultValue: 0 },
    { type: 'currency', path: 'total', label: 'Total', disabled: true },
  ]}
  computedFields={[
    {
      targetField: 'total',
      formula: 'quantity * unitPrice * (1 - discount / 100)',
      dependencies: ['quantity', 'unitPrice', 'discount']
    }
  ]}
  hint="Change quantity, price, or discount to see the total update automatically"
/>
```

---

## 4. Architecture

### 4.1 Component Structure

```
src/components/FormPreview/
├── index.tsx                    # Main export
├── FormPreview.tsx              # Container component
├── FormPreviewToolbar.tsx       # Tab switcher, viewport, reset
├── FormPreviewCanvas.tsx        # Responsive wrapper for form
├── FormPreviewConfig.tsx        # Config viewer with syntax highlighting
├── FormRenderer.tsx             # Actual form rendering (extracted from platform)
├── fields/                      # Individual field components
│   ├── index.ts                 # Field registry
│   ├── ShortTextField.tsx
│   ├── EmailField.tsx
│   ├── DropdownField.tsx
│   ├── RatingField.tsx
│   └── ... (30+ field types)
├── hooks/
│   ├── useFormState.ts          # Form values and validation state
│   ├── useConditionalLogic.ts   # Conditional visibility evaluation
│   ├── useComputedFields.ts     # Formula evaluation
│   └── useFormConfig.ts         # Config serialization
├── utils/
│   ├── configSerializer.ts      # JSON/TypeScript export
│   ├── templateLoader.ts        # Load templates by ID
│   └── validators.ts            # Field validation logic
├── styles/
│   └── FormPreview.module.css   # Component styles
└── types.ts                     # TypeScript interfaces
```

### 4.2 Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                         FormPreview                             │
│                                                                 │
│  ┌──────────────┐     ┌──────────────┐     ┌────────────────┐  │
│  │    Props     │────▶│  useFormState │────▶│  FormRenderer  │  │
│  │  (fields,    │     │  (values,     │     │  (renders      │  │
│  │   template)  │     │   errors)     │     │   fields)      │  │
│  └──────────────┘     └──────────────┘     └────────────────┘  │
│         │                    │                      │           │
│         │                    │                      │           │
│         ▼                    ▼                      ▼           │
│  ┌──────────────┐     ┌──────────────┐     ┌────────────────┐  │
│  │ useFormConfig│     │useConditional│     │ useComputed    │  │
│  │ (serialize)  │     │Logic (filter)│     │ Fields (calc)  │  │
│  └──────────────┘     └──────────────┘     └────────────────┘  │
│         │                                                       │
│         ▼                                                       │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              FormPreviewConfig (syntax highlight)         │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### 4.3 Key Implementation Decisions

#### Decision 1: Extract vs. Duplicate Field Renderers

**Options:**

| Option | Pros | Cons |
|--------|------|------|
| **A: Extract from netpad-3** | Single source of truth, guaranteed parity | Package dependency, build complexity |
| **B: Duplicate for docs** | Independent, simpler build | Drift risk, maintenance burden |
| **C: Shared package** | Clean architecture, reusable | Upfront investment, versioning overhead |

**Recommendation:** Option C — Create `@netpad/form-renderer` package

This package would:
- Contain all 30+ field components
- Be used by both netpad-3 platform AND docs site
- Ensure visual parity by definition
- Become foundation for future `@netpad/forms` package

**Migration path:**
1. Start with Option B (duplicate) for v1 speed
2. Refactor to Option C when stabilized
3. Document which fields are implemented in each phase

#### Decision 2: Styling Approach

**Options:**

| Option | Pros | Cons |
|--------|------|------|
| **A: MUI (match platform)** | Exact visual parity | Large bundle, Docusaurus integration |
| **B: CSS Modules** | Lightweight, Docusaurus-native | Must manually match platform styles |
| **C: Tailwind** | Utility-first, common in docs | Doesn't match platform (MUI) |

**Recommendation:** Option A for field internals, Option B for preview wrapper

- Field components use MUI to match production exactly
- Preview chrome (toolbar, tabs, viewport frame) uses CSS Modules
- This keeps the "form" looking production-accurate while the "preview wrapper" fits Docusaurus

#### Decision 3: Template Loading

**Options:**

| Option | Pros | Cons |
|--------|------|------|
| **A: Bundled JSON** | Fast, offline works | Bundle size, stale templates |
| **B: Fetch from API** | Always current | Requires network, CORS, auth |
| **C: Import from @netpad/templates** | NPM versioned, matches launch | Build-time only |

**Recommendation:** Option C — Import from `@netpad/templates`

Since `@netpad/templates` is launching Feb 1, this:
- Validates the package works in a real consumer
- Keeps docs in sync with published templates
- Requires no runtime API calls

```typescript
// templateLoader.ts
import { templates } from '@netpad/templates';

export function loadTemplate(templateId: string): FormConfig {
  const template = templates.find(t => t.id === templateId);
  if (!template) throw new Error(`Template not found: ${templateId}`);
  return template.config;
}
```

---

## 5. Implementation Phases

### Phase 1: Foundation (Week 1)

**Goal:** Basic form preview with core field types

**Deliverables:**
- [ ] FormPreview container component
- [ ] FormPreviewToolbar (tabs only, no viewport switcher yet)
- [ ] FormRenderer with 10 essential field types:
  - `short_text`, `long_text`, `email`, `phone`, `number`
  - `dropdown`, `radio`, `checkbox`, `date`, `toggle`
- [ ] useFormState hook (values, basic validation)
- [ ] FormPreviewConfig with JSON export
- [ ] Basic dark theme styling

**Acceptance Criteria:**
- Can render a 5-field form in docs
- Fields accept input and show validation errors
- Can toggle to see JSON config
- Copy button works

### Phase 2: Full Field Support (Week 2)

**Goal:** All 30+ field types rendered

**Deliverables:**
- [ ] Remaining 20+ field types:
  - `currency`, `rating`, `slider`, `file_upload`, `signature`
  - `address`, `url`, `color`, `time`, `datetime`
  - `multi_select`, `matrix`, `ranking`, `scale`
  - `section`, `divider`, `heading`, `html`, `hidden`
  - `computed` (display only in phase 2)
- [ ] TypeScript config export format
- [ ] Format switcher (JSON/TypeScript)

**Acceptance Criteria:**
- Every field type in NetPad can be previewed
- TypeScript export generates valid, usable config

### Phase 3: Advanced Features (Week 3)

**Goal:** Conditional logic, computed fields, responsive preview

**Deliverables:**
- [ ] useConditionalLogic hook
- [ ] useComputedFields hook (formula evaluation)
- [ ] Viewport switcher (mobile/tablet/desktop)
- [ ] Responsive canvas wrapper
- [ ] Template loading from `@netpad/templates`
- [ ] `template` prop support

**Acceptance Criteria:**
- Conditional logic demo works (show/hide fields)
- Computed fields demo works (formulas calculate)
- Can switch viewports and see responsive behavior
- Can load any template by ID

### Phase 4: Polish & Documentation (Week 4)

**Goal:** Production-ready component with docs

**Deliverables:**
- [ ] Light/dark/auto theme support
- [ ] Hint/instruction text display
- [ ] Reset functionality
- [ ] Height constraints and scrolling
- [ ] Error boundaries and loading states
- [ ] Storybook stories for all variants
- [ ] Component documentation (props, examples)
- [ ] Integration into actual docs pages

**Acceptance Criteria:**
- Component handles all edge cases gracefully
- Documented in Storybook with all variants
- Integrated into at least 5 docs pages

---

## 6. Field Type Implementation Tracker

Use this to track progress across phases:

| Field Type | Category | Phase | Status | Notes |
|------------|----------|-------|--------|-------|
| `short_text` | Text | 1 | ⬜ | Basic text input |
| `long_text` | Text | 1 | ⬜ | Textarea with rows |
| `email` | Text | 1 | ⬜ | Email validation |
| `phone` | Text | 1 | ⬜ | Phone formatting |
| `number` | Text | 1 | ⬜ | Numeric input |
| `currency` | Text | 2 | ⬜ | Currency formatting |
| `url` | Text | 2 | ⬜ | URL validation |
| `dropdown` | Selection | 1 | ⬜ | Single select |
| `multi_select` | Selection | 2 | ⬜ | Multiple select |
| `radio` | Selection | 1 | ⬜ | Radio group |
| `checkbox` | Selection | 1 | ⬜ | Checkbox group |
| `toggle` | Selection | 1 | ⬜ | Boolean switch |
| `date` | Date/Time | 1 | ⬜ | Date picker |
| `time` | Date/Time | 2 | ⬜ | Time picker |
| `datetime` | Date/Time | 2 | ⬜ | Combined picker |
| `rating` | Interactive | 2 | ⬜ | Star/icon rating |
| `slider` | Interactive | 2 | ⬜ | Range slider |
| `scale` | Interactive | 2 | ⬜ | Likert scale |
| `ranking` | Interactive | 2 | ⬜ | Drag to rank |
| `matrix` | Interactive | 2 | ⬜ | Grid questions |
| `file_upload` | Media | 2 | ⬜ | File input (mock) |
| `signature` | Media | 2 | ⬜ | Signature pad |
| `color` | Media | 2 | ⬜ | Color picker |
| `address` | Composite | 2 | ⬜ | Address fields |
| `section` | Layout | 2 | ⬜ | Visual grouping |
| `divider` | Layout | 2 | ⬜ | Horizontal rule |
| `heading` | Layout | 2 | ⬜ | Text heading |
| `html` | Layout | 2 | ⬜ | Custom HTML |
| `hidden` | Utility | 2 | ⬜ | Hidden field |
| `computed` | Utility | 3 | ⬜ | Formula field |

---

## 7. Dependencies

### 7.1 NPM Packages

```json
{
  "dependencies": {
    "@mui/material": "^5.x",
    "@mui/icons-material": "^5.x",
    "@emotion/react": "^11.x",
    "@emotion/styled": "^11.x",
    "@netpad/templates": "^1.x",
    "prism-react-renderer": "^2.x",
    "mathjs": "^12.x"
  },
  "devDependencies": {
    "@types/react": "^18.x",
    "typescript": "^5.x"
  }
}
```

### 7.2 Docusaurus Integration

Add to `docusaurus.config.js`:

```javascript
module.exports = {
  // ...
  plugins: [
    // May need custom webpack config for MUI
    function (context, options) {
      return {
        name: 'custom-webpack',
        configureWebpack(config, isServer, utils) {
          return {
            resolve: {
              alias: {
                '@mui/styled-engine': '@mui/styled-engine-sc',
              },
            },
          };
        },
      };
    },
  ],
};
```

---

## 8. Testing Strategy

### 8.1 Unit Tests

| Component | Test Cases |
|-----------|------------|
| useFormState | Initial values, value updates, validation triggers |
| useConditionalLogic | Show/hide rules, multiple conditions, nested logic |
| useComputedFields | Formula evaluation, dependency updates, error handling |
| configSerializer | JSON output, TypeScript output, special characters |
| Each field type | Renders correctly, accepts input, validates |

### 8.2 Integration Tests

| Scenario | Test Case |
|----------|-----------|
| Basic preview | Renders fields, accepts input, shows validation |
| Conditional logic | Fields show/hide based on input |
| Computed fields | Values calculate on dependency change |
| Config export | Copy button produces valid config |
| Template loading | Loads template by ID, renders all fields |
| Viewport switching | Canvas resizes appropriately |

### 8.3 Visual Regression

Use Storybook + Chromatic (or Percy) to catch visual regressions:
- Each field type in various states
- Light and dark themes
- Mobile/tablet/desktop viewports

---

## 9. Open Questions

| # | Question | Options | Decision Needed By |
|---|----------|---------|-------------------|
| 1 | Should file_upload show a mock or be disabled? | Mock upload UI / Disabled with tooltip | Phase 2 start |
| 2 | How to handle signature field (canvas-based)? | Simplified mock / Full canvas | Phase 2 start |
| 3 | Should we support multi-page forms in preview? | Yes with pagination / No, single page only | Phase 3 start |
| 4 | Bundle size budget for docs site? | Need baseline measurement | Phase 1 start |
| 5 | Should config export include validation rules? | Always / Optional toggle | Phase 2 |
| 6 | Light theme design—match MUI default or custom? | MUI default / Custom NetPad light | Phase 4 |

---

## 10. Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Bundle size impact | <200KB gzipped | Webpack analyzer |
| Time to interactive | <1s on 3G | Lighthouse |
| Field type coverage | 100% (30+ types) | Manual audit |
| Visual parity with platform | >95% similarity | Visual regression |
| Config export accuracy | 100% valid configs | Automated test |
| Docs pages using component | 10+ pages | Manual count |

---

## 11. Appendix

### A. Example Template Structure

From `@netpad/templates`:

```typescript
// @netpad/templates/src/forms/contact-form.ts
export const contactFormTemplate: FormTemplate = {
  id: 'contact-form',
  name: 'Contact Form',
  description: 'Simple contact form with name, email, and message',
  category: 'business',
  fields: [
    { type: 'short_text', path: 'name', label: 'Full Name', required: true },
    { type: 'email', path: 'email', label: 'Email Address', required: true },
    { type: 'dropdown', path: 'subject', label: 'Subject', 
      options: [
        { label: 'General Inquiry', value: 'general' },
        { label: 'Support', value: 'support' },
        { label: 'Sales', value: 'sales' },
      ]
    },
    { type: 'long_text', path: 'message', label: 'Message', required: true, rows: 5 },
  ],
  settings: {
    submitButtonText: 'Send Message',
  },
};
```

### B. Conditional Logic Schema

```typescript
interface ConditionalRule {
  action: 'show' | 'hide' | 'require' | 'disable';
  targetField: string;  // path of field to affect
  logicType: 'all' | 'any';  // AND vs OR
  conditions: Condition[];
}

interface Condition {
  field: string;  // path of field to check
  operator: 'equals' | 'not_equals' | 'contains' | 'greater_than' | 'less_than' | 'is_empty' | 'is_not_empty';
  value?: any;  // not needed for is_empty/is_not_empty
}
```

### C. Computed Field Formula Syntax

Using mathjs for formula evaluation:

```typescript
interface ComputedFieldConfig {
  targetField: string;  // path of computed field
  formula: string;  // mathjs expression, field paths as variables
  dependencies: string[];  // field paths that trigger recalculation
  format?: 'number' | 'currency' | 'percentage';  // output formatting
}

// Example formulas:
// 'quantity * unitPrice'
// 'subtotal * (1 + taxRate / 100)'
// 'round(total, 2)'
// 'max(0, revenue - expenses)'
```

---

## 12. Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | January 2025 | Michael | Initial specification |

---

## 13. Next Steps

1. Review with AI engineering team
2. Resolve open questions (Section 9)
3. Finalize Phase 1 scope
4. Begin implementation

---

*End of Specification*
