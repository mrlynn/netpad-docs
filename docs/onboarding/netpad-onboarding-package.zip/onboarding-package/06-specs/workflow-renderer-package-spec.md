# @netpad/workflow-renderer

## NPM Package Technical Specification

**Version:** 1.0.0  
**Status:** Draft  
**Author:** Michael  
**Package Name:** `@netpad/workflow-renderer`

---

## 1. Overview

### 1.1 Purpose

`@netpad/workflow-renderer` is a React component library for rendering NetPad workflow definitions as interactive, read-only visualizations. Built on ReactFlow, it provides consistent workflow visualization across all NetPad surfaces—the platform, documentation, embedded views, and standalone exports.

### 1.2 Goals

| Goal | Description | Success Metric |
|------|-------------|----------------|
| **Visual parity** | Identical rendering across all consumers | No visual differences between platform and docs |
| **Read-only focus** | Optimized for display, not editing | Clean API without edit complexity |
| **All node types** | Support all 25+ workflow node types | 100% node type coverage |
| **Auto-layout** | Render workflows without position data | Dagre layout produces readable graphs |
| **Themeable** | Support light/dark and custom themes | Theme prop controls all colors |
| **Lightweight** | Minimal bundle for what it does | <200KB total (including ReactFlow) |

### 1.3 Non-Goals (v1)

- Editing capabilities (drag/drop, connections, node config)
- Workflow execution or simulation
- Real-time collaboration features
- Node configuration panels
- Undo/redo functionality
- Connection validation during editing

These belong in a future `@netpad/workflow-editor` package.

### 1.4 Target Consumers

| Consumer | Use Case |
|----------|----------|
| **netpad-3 platform** | Workflow preview mode, read-only views |
| **docs.netpad.io** | Documentation examples, template previews |
| **Standalone exports** | Exported apps displaying workflow diagrams |
| **Customer embeds** | Workflow status dashboards |
| **Marketing site** | Landing page demos |

---

## 2. Package API

### 2.1 Installation

```bash
npm install @netpad/workflow-renderer
# or
yarn add @netpad/workflow-renderer
# or
pnpm add @netpad/workflow-renderer
```

### 2.2 Peer Dependencies

```json
{
  "peerDependencies": {
    "react": ">=18.0.0",
    "react-dom": ">=18.0.0"
  }
}
```

### 2.3 Basic Usage

```tsx
import { WorkflowRenderer } from '@netpad/workflow-renderer';
import '@netpad/workflow-renderer/styles.css';

const workflow = {
  nodes: [
    { id: 'trigger', type: 'form_trigger', position: { x: 0, y: 0 }, data: { label: 'Form Submit' } },
    { id: 'email', type: 'email_send', position: { x: 200, y: 0 }, data: { label: 'Send Email' } },
  ],
  edges: [
    { id: 'e1', source: 'trigger', target: 'email' },
  ],
};

function App() {
  return (
    <WorkflowRenderer
      workflow={workflow}
      height={400}
    />
  );
}
```

### 2.4 With Auto-Layout

```tsx
import { WorkflowRenderer } from '@netpad/workflow-renderer';

// Nodes without position data
const workflow = {
  nodes: [
    { id: 'trigger', type: 'form_trigger', data: { label: 'Form Submit' } },
    { id: 'filter', type: 'filter', data: { label: 'Priority = High?' } },
    { id: 'email', type: 'email_send', data: { label: 'Send to IT' } },
    { id: 'slack', type: 'slack_send', data: { label: 'Post to #general' } },
  ],
  edges: [
    { id: 'e1', source: 'trigger', target: 'filter' },
    { id: 'e2', source: 'filter', target: 'email', data: { label: 'yes' } },
    { id: 'e3', source: 'filter', target: 'slack', data: { label: 'no' } },
  ],
};

function App() {
  return (
    <WorkflowRenderer
      workflow={workflow}
      autoLayout={true}
      layoutDirection="TB"  // top-to-bottom
      height={400}
    />
  );
}
```

---

## 3. Component API Reference

### 3.1 WorkflowRenderer

Main component for rendering workflows.

```typescript
interface WorkflowRendererProps {
  // === REQUIRED ===
  
  /** Workflow definition to render */
  workflow: WorkflowDefinition;
  
  // === DIMENSIONS ===
  
  /** Height of the renderer (required for proper ReactFlow sizing) */
  height: number | string;  // e.g., 400 or '100%'
  
  /** Width of the renderer */
  width?: number | string;  // default: '100%'
  
  // === LAYOUT ===
  
  /** Enable auto-layout for workflows without position data */
  autoLayout?: boolean;  // default: false
  
  /** Direction for auto-layout */
  layoutDirection?: 'TB' | 'BT' | 'LR' | 'RL';  // default: 'TB' (top-to-bottom)
  
  /** Spacing between nodes (auto-layout) */
  nodeSpacing?: number;  // default: 50
  
  /** Spacing between ranks/levels (auto-layout) */
  rankSpacing?: number;  // default: 100
  
  // === APPEARANCE ===
  
  /** Theme preset or custom theme */
  theme?: 'light' | 'dark' | RendererTheme;  // default: 'dark'
  
  /** Show minimap */
  showMinimap?: boolean;  // default: false
  
  /** Minimap position */
  minimapPosition?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';  // default: 'bottom-right'
  
  /** Show zoom controls */
  showControls?: boolean;  // default: true
  
  /** Show background grid/dots */
  showBackground?: boolean;  // default: true
  
  /** Background variant */
  backgroundVariant?: 'dots' | 'lines' | 'none';  // default: 'dots'
  
  // === INTERACTION ===
  
  /** Allow panning */
  pannable?: boolean;  // default: true
  
  /** Allow zooming */
  zoomable?: boolean;  // default: true
  
  /** Min zoom level */
  minZoom?: number;  // default: 0.25
  
  /** Max zoom level */
  maxZoom?: number;  // default: 2
  
  /** Initial zoom level */
  defaultZoom?: number;  // default: 1
  
  /** Fit view to show all nodes on load */
  fitView?: boolean;  // default: true
  
  /** Padding around fitted view */
  fitViewPadding?: number;  // default: 0.2
  
  // === CALLBACKS ===
  
  /** Called when a node is clicked */
  onNodeClick?: (node: WorkflowNode) => void;
  
  /** Called when an edge is clicked */
  onEdgeClick?: (edge: WorkflowEdge) => void;
  
  /** Called when renderer is ready */
  onLoad?: () => void;
  
  // === ADVANCED ===
  
  /** Custom node type components (override defaults) */
  customNodes?: Record<string, React.ComponentType<NodeProps>>;
  
  /** Custom edge type components (override defaults) */
  customEdges?: Record<string, React.ComponentType<EdgeProps>>;
  
  /** Additional class name */
  className?: string;
  
  /** Additional inline styles */
  style?: React.CSSProperties;
}
```

### 3.2 WorkflowMinimap

Standalone minimap component (if not using `showMinimap` prop).

```typescript
interface WorkflowMinimapProps {
  /** Position on screen */
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  
  /** Width of minimap */
  width?: number;  // default: 150
  
  /** Height of minimap */
  height?: number;  // default: 100
  
  /** Node color or color function */
  nodeColor?: string | ((node: WorkflowNode) => string);
  
  /** Mask color (area outside viewport) */
  maskColor?: string;
  
  /** Additional class name */
  className?: string;
}
```

### 3.3 Individual Node Components

Exported for advanced customization:

```typescript
import { 
  FormTriggerNode,
  WebhookTriggerNode,
  FilterNode,
  EmailSendNode,
  // ... all node types
} from '@netpad/workflow-renderer/nodes';
```

---

## 4. Type Definitions

### 4.1 Core Types

```typescript
// Main workflow definition
interface WorkflowDefinition {
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  viewport?: Viewport;  // optional saved viewport state
}

// Individual node
interface WorkflowNode {
  id: string;
  type: NodeType;
  position?: { x: number; y: number };  // optional if using autoLayout
  data: NodeData;
  width?: number;
  height?: number;
}

// Node data (varies by type)
interface NodeData {
  label: string;
  description?: string;
  icon?: string;
  config?: Record<string, any>;  // type-specific configuration
  status?: 'idle' | 'running' | 'success' | 'error';  // for execution display
  error?: string;
}

// Edge connecting nodes
interface WorkflowEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
  type?: EdgeType;
  data?: EdgeData;
  animated?: boolean;
}

// Edge data
interface EdgeData {
  label?: string;
  condition?: string;  // for conditional edges
}

// Viewport state
interface Viewport {
  x: number;
  y: number;
  zoom: number;
}
```

### 4.2 Node Types

```typescript
type NodeType =
  // Triggers (4)
  | 'form_trigger'
  | 'webhook_trigger'
  | 'schedule_trigger'
  | 'manual_trigger'
  
  // Logic (6)
  | 'filter'
  | 'switch'
  | 'delay'
  | 'loop'
  | 'parallel'
  | 'merge'
  
  // Data (5)
  | 'mongodb_query'
  | 'mongodb_insert'
  | 'mongodb_update'
  | 'mongodb_delete'
  | 'transform'
  
  // Actions (7)
  | 'email_send'
  | 'slack_send'
  | 'webhook_call'
  | 'http_request'
  | 'sms_send'
  | 'push_notification'
  | 'function'
  
  // AI (4)
  | 'llm_generate'
  | 'llm_classify'
  | 'llm_extract'
  | 'llm_summarize'
  
  // Utility (3)
  | 'note'
  | 'variable_set'
  | 'variable_get';
```

### 4.3 Edge Types

```typescript
type EdgeType =
  | 'default'       // standard connection
  | 'conditional'   // shows condition label
  | 'error'         // error path (red)
  | 'animated';     // animated flow
```

### 4.4 Theme Types

```typescript
interface RendererTheme {
  // Canvas
  background: string;
  backgroundPattern: string;
  
  // Nodes
  node: {
    background: string;
    border: string;
    borderRadius: number;
    text: string;
    textSecondary: string;
    shadow: string;
  };
  
  // Node categories (color coding)
  nodeCategories: {
    trigger: string;   // e.g., '#10B981' (green)
    logic: string;     // e.g., '#F59E0B' (amber)
    data: string;      // e.g., '#3B82F6' (blue)
    action: string;    // e.g., '#8B5CF6' (purple)
    ai: string;        // e.g., '#EC4899' (pink)
    utility: string;   // e.g., '#64748B' (slate)
  };
  
  // Edges
  edge: {
    default: string;
    selected: string;
    animated: string;
    error: string;
    label: string;
    labelBackground: string;
  };
  
  // Controls
  controls: {
    background: string;
    border: string;
    icon: string;
    iconHover: string;
  };
  
  // Minimap
  minimap: {
    background: string;
    mask: string;
    node: string;
  };
  
  // Status indicators
  status: {
    idle: string;
    running: string;
    success: string;
    error: string;
  };
}
```

---

## 5. Built-in Themes

### 5.1 Dark Theme (Default)

```typescript
import { darkTheme } from '@netpad/workflow-renderer/themes';

// Colors optimized for dark backgrounds
// Matches NetPad platform dark mode
```

### 5.2 Light Theme

```typescript
import { lightTheme } from '@netpad/workflow-renderer/themes';

// Colors optimized for light backgrounds
```

### 5.3 Custom Theme

```typescript
import { WorkflowRenderer, createTheme, darkTheme } from '@netpad/workflow-renderer';

const customTheme = createTheme({
  ...darkTheme,
  nodeCategories: {
    ...darkTheme.nodeCategories,
    trigger: '#00FF00',  // custom trigger color
  },
});

<WorkflowRenderer
  workflow={workflow}
  theme={customTheme}
  height={400}
/>
```

---

## 6. Auto-Layout System

### 6.1 Layout Algorithm

Uses Dagre for directed acyclic graph layout:

```typescript
import { autoLayout } from '@netpad/workflow-renderer';

// Manually apply layout to workflow
const layoutedWorkflow = autoLayout(workflow, {
  direction: 'TB',
  nodeSpacing: 50,
  rankSpacing: 100,
});
```

### 6.2 Layout Options

```typescript
interface LayoutOptions {
  /** Layout direction */
  direction: 'TB' | 'BT' | 'LR' | 'RL';
  
  /** Horizontal spacing between nodes */
  nodeSpacing: number;
  
  /** Vertical spacing between ranks */
  rankSpacing: number;
  
  /** Algorithm for ranking nodes */
  ranker?: 'network-simplex' | 'tight-tree' | 'longest-path';
  
  /** Alignment within rank */
  align?: 'UL' | 'UR' | 'DL' | 'DR';
}
```

### 6.3 Layout Directions

```
TB (Top-to-Bottom)        LR (Left-to-Right)
       ┌───┐                    ┌───┐   ┌───┐   ┌───┐
       │ A │                    │ A │───│ B │───│ C │
       └─┬─┘                    └───┘   └───┘   └───┘
         │
       ┌─┴─┐
       │ B │
       └─┬─┘
         │
       ┌─┴─┐
       │ C │
       └───┘
```

---

## 7. Node Type Specifications

### 7.1 Node Anatomy

All nodes share a common structure:

```
┌─────────────────────────────────────┐
│ ┌───┐                               │
│ │ ● │  Node Label                   │
│ └───┘  Optional description         │
│        ┌─────────────────────────┐  │
│        │ Config preview (if any) │  │
│        └─────────────────────────┘  │
└─────────────────────────────────────┘
     │                           │
   input                      output
  handle                      handle
```

### 7.2 Node Categories & Colors

| Category | Color | Node Types |
|----------|-------|------------|
| **Trigger** | Green `#10B981` | form_trigger, webhook_trigger, schedule_trigger, manual_trigger |
| **Logic** | Amber `#F59E0B` | filter, switch, delay, loop, parallel, merge |
| **Data** | Blue `#3B82F6` | mongodb_query, mongodb_insert, mongodb_update, mongodb_delete, transform |
| **Action** | Purple `#8B5CF6` | email_send, slack_send, webhook_call, http_request, sms_send, push_notification, function |
| **AI** | Pink `#EC4899` | llm_generate, llm_classify, llm_extract, llm_summarize |
| **Utility** | Slate `#64748B` | note, variable_set, variable_get |

### 7.3 Node Type Details

#### Triggers

| Type | Icon | Handles | Config Preview |
|------|------|---------|----------------|
| `form_trigger` | 📋 | 1 output | Form name |
| `webhook_trigger` | 🔗 | 1 output | HTTP method |
| `schedule_trigger` | ⏰ | 1 output | Cron expression |
| `manual_trigger` | 👆 | 1 output | - |

#### Logic

| Type | Icon | Handles | Config Preview |
|------|------|---------|----------------|
| `filter` | 🔍 | 1 input, 2 outputs (yes/no) | Condition summary |
| `switch` | 🔀 | 1 input, N outputs | Case labels |
| `delay` | ⏳ | 1 input, 1 output | Duration |
| `loop` | 🔁 | 1 input, 2 outputs (loop/done) | Iterator |
| `parallel` | ⚡ | 1 input, N outputs | Branch count |
| `merge` | 🔄 | N inputs, 1 output | Merge strategy |

#### Data

| Type | Icon | Handles | Config Preview |
|------|------|---------|----------------|
| `mongodb_query` | 🔎 | 1 input, 1 output | Collection name |
| `mongodb_insert` | ➕ | 1 input, 1 output | Collection name |
| `mongodb_update` | ✏️ | 1 input, 1 output | Collection name |
| `mongodb_delete` | 🗑️ | 1 input, 1 output | Collection name |
| `transform` | 🔄 | 1 input, 1 output | Transform type |

#### Actions

| Type | Icon | Handles | Config Preview |
|------|------|---------|----------------|
| `email_send` | ✉️ | 1 input, 1 output | Recipient |
| `slack_send` | 💬 | 1 input, 1 output | Channel |
| `webhook_call` | 🌐 | 1 input, 1 output | URL (truncated) |
| `http_request` | 🔌 | 1 input, 1 output | Method + URL |
| `sms_send` | 📱 | 1 input, 1 output | - |
| `push_notification` | 🔔 | 1 input, 1 output | - |
| `function` | ⚙️ | 1 input, 1 output | Function name |

#### AI

| Type | Icon | Handles | Config Preview |
|------|------|---------|----------------|
| `llm_generate` | 🤖 | 1 input, 1 output | Model |
| `llm_classify` | 🏷️ | 1 input, N outputs | Categories |
| `llm_extract` | 📤 | 1 input, 1 output | Schema fields |
| `llm_summarize` | 📝 | 1 input, 1 output | - |

#### Utility

| Type | Icon | Handles | Config Preview |
|------|------|---------|----------------|
| `note` | 📌 | 0 | Note text |
| `variable_set` | 📥 | 1 input, 1 output | Variable name |
| `variable_get` | 📤 | 1 output | Variable name |

---

## 8. Package Structure

```
@netpad/workflow-renderer/
├── package.json
├── tsconfig.json
├── tsup.config.ts              # Build configuration
├── README.md
├── LICENSE
├── CHANGELOG.md
│
├── src/
│   ├── index.ts                # Public exports
│   │
│   ├── WorkflowRenderer.tsx    # Main component
│   ├── WorkflowMinimap.tsx     # Minimap component
│   ├── WorkflowControls.tsx    # Zoom/pan controls
│   ├── WorkflowBackground.tsx  # Background pattern
│   │
│   ├── nodes/
│   │   ├── index.ts            # Node registry & exports
│   │   ├── BaseNode.tsx        # Shared node wrapper
│   │   ├── NodeHandle.tsx      # Input/output handles
│   │   │
│   │   ├── triggers/
│   │   │   ├── FormTriggerNode.tsx
│   │   │   ├── WebhookTriggerNode.tsx
│   │   │   ├── ScheduleTriggerNode.tsx
│   │   │   └── ManualTriggerNode.tsx
│   │   │
│   │   ├── logic/
│   │   │   ├── FilterNode.tsx
│   │   │   ├── SwitchNode.tsx
│   │   │   ├── DelayNode.tsx
│   │   │   ├── LoopNode.tsx
│   │   │   ├── ParallelNode.tsx
│   │   │   └── MergeNode.tsx
│   │   │
│   │   ├── data/
│   │   │   ├── MongoQueryNode.tsx
│   │   │   ├── MongoInsertNode.tsx
│   │   │   ├── MongoUpdateNode.tsx
│   │   │   ├── MongoDeleteNode.tsx
│   │   │   └── TransformNode.tsx
│   │   │
│   │   ├── actions/
│   │   │   ├── EmailSendNode.tsx
│   │   │   ├── SlackSendNode.tsx
│   │   │   ├── WebhookCallNode.tsx
│   │   │   ├── HttpRequestNode.tsx
│   │   │   ├── SmsSendNode.tsx
│   │   │   ├── PushNotificationNode.tsx
│   │   │   └── FunctionNode.tsx
│   │   │
│   │   ├── ai/
│   │   │   ├── LLMGenerateNode.tsx
│   │   │   ├── LLMClassifyNode.tsx
│   │   │   ├── LLMExtractNode.tsx
│   │   │   └── LLMSummarizeNode.tsx
│   │   │
│   │   └── utility/
│   │       ├── NoteNode.tsx
│   │       ├── VariableSetNode.tsx
│   │       └── VariableGetNode.tsx
│   │
│   ├── edges/
│   │   ├── index.ts            # Edge registry & exports
│   │   ├── DefaultEdge.tsx
│   │   ├── ConditionalEdge.tsx
│   │   └── ErrorEdge.tsx
│   │
│   ├── layout/
│   │   ├── index.ts
│   │   ├── autoLayout.ts       # Main layout function
│   │   └── dagre.ts            # Dagre integration
│   │
│   ├── themes/
│   │   ├── index.ts
│   │   ├── dark.ts
│   │   ├── light.ts
│   │   └── createTheme.ts
│   │
│   ├── hooks/
│   │   ├── useWorkflowRenderer.ts
│   │   ├── useAutoLayout.ts
│   │   └── useTheme.ts
│   │
│   ├── types/
│   │   ├── index.ts            # Re-exports all types
│   │   ├── workflow.ts         # WorkflowDefinition, etc.
│   │   ├── nodes.ts            # Node types
│   │   ├── edges.ts            # Edge types
│   │   ├── theme.ts            # Theme types
│   │   └── props.ts            # Component props
│   │
│   └── utils/
│       ├── nodeRegistry.ts     # Maps type string to component
│       ├── edgeRegistry.ts     # Maps type string to component
│       ├── validation.ts       # Workflow validation
│       └── helpers.ts          # Misc utilities
│
├── styles/
│   ├── base.css                # Base styles
│   ├── nodes.css               # Node styles
│   ├── edges.css               # Edge styles
│   └── themes.css              # Theme CSS variables
│
└── __tests__/
    ├── WorkflowRenderer.test.tsx
    ├── autoLayout.test.ts
    ├── nodes/
    │   └── ... (node component tests)
    └── utils/
        └── validation.test.ts
```

---

## 9. Dependencies

### 9.1 Production Dependencies

```json
{
  "dependencies": {
    "reactflow": "^11.10.0",
    "dagre": "^0.8.5",
    "@dagrejs/dagre": "^1.0.0"
  }
}
```

### 9.2 Peer Dependencies

```json
{
  "peerDependencies": {
    "react": ">=18.0.0",
    "react-dom": ">=18.0.0"
  }
}
```

### 9.3 Dev Dependencies

```json
{
  "devDependencies": {
    "typescript": "^5.0.0",
    "tsup": "^8.0.0",
    "@types/react": "^18.0.0",
    "@types/dagre": "^0.7.0",
    "vitest": "^1.0.0",
    "@testing-library/react": "^14.0.0"
  }
}
```

---

## 10. Build Configuration

### 10.1 Package.json Exports

```json
{
  "name": "@netpad/workflow-renderer",
  "version": "1.0.0",
  "main": "./dist/index.js",
  "module": "./dist/index.mjs",
  "types": "./dist/index.d.ts",
  "exports": {
    ".": {
      "import": "./dist/index.mjs",
      "require": "./dist/index.js",
      "types": "./dist/index.d.ts"
    },
    "./nodes": {
      "import": "./dist/nodes/index.mjs",
      "require": "./dist/nodes/index.js",
      "types": "./dist/nodes/index.d.ts"
    },
    "./edges": {
      "import": "./dist/edges/index.mjs",
      "require": "./dist/edges/index.js",
      "types": "./dist/edges/index.d.ts"
    },
    "./themes": {
      "import": "./dist/themes/index.mjs",
      "require": "./dist/themes/index.js",
      "types": "./dist/themes/index.d.ts"
    },
    "./layout": {
      "import": "./dist/layout/index.mjs",
      "require": "./dist/layout/index.js",
      "types": "./dist/layout/index.d.ts"
    },
    "./styles.css": "./dist/styles.css"
  },
  "files": [
    "dist"
  ],
  "sideEffects": [
    "*.css"
  ]
}
```

### 10.2 tsup.config.ts

```typescript
import { defineConfig } from 'tsup';

export default defineConfig({
  entry: [
    'src/index.ts',
    'src/nodes/index.ts',
    'src/edges/index.ts',
    'src/themes/index.ts',
    'src/layout/index.ts',
  ],
  format: ['cjs', 'esm'],
  dts: true,
  splitting: true,
  sourcemap: true,
  clean: true,
  external: ['react', 'react-dom'],
  treeshake: true,
});
```

---

## 11. Implementation Phases

### Phase 1: Core Renderer (Week 1-2)

**Goal:** Basic workflow rendering with common node types

**Deliverables:**
- [ ] Package setup (tsup, TypeScript, testing)
- [ ] WorkflowRenderer main component
- [ ] ReactFlow integration
- [ ] BaseNode component
- [ ] 10 essential node types:
  - Triggers: `form_trigger`, `webhook_trigger`
  - Logic: `filter`, `switch`, `delay`
  - Actions: `email_send`, `slack_send`
  - Data: `mongodb_query`
  - AI: `llm_generate`
  - Utility: `note`
- [ ] Default edge type
- [ ] Dark theme

**Acceptance Criteria:**
- Can render a workflow with supported node types
- Nodes display correctly with icons and labels
- Edges connect properly
- Panning and zooming work

### Phase 2: Complete Node Coverage (Week 3)

**Goal:** All 25+ node types implemented

**Deliverables:**
- [ ] Remaining trigger nodes
- [ ] Remaining logic nodes (loop, parallel, merge)
- [ ] Remaining data nodes
- [ ] Remaining action nodes
- [ ] Remaining AI nodes
- [ ] Utility nodes
- [ ] Conditional edge type
- [ ] Error edge type

**Acceptance Criteria:**
- 100% node type coverage
- All node categories have distinct colors
- Config previews show relevant data

### Phase 3: Auto-Layout (Week 4)

**Goal:** Automatic layout for position-less workflows

**Deliverables:**
- [ ] Dagre integration
- [ ] `autoLayout` function
- [ ] Layout direction options (TB, LR, etc.)
- [ ] Spacing configuration
- [ ] `autoLayout` prop on WorkflowRenderer

**Acceptance Criteria:**
- Workflows without position data render correctly
- Layout is readable and professional
- Different directions work as expected

### Phase 4: Theming & Polish (Week 5)

**Goal:** Production-ready with full theming

**Deliverables:**
- [ ] Light theme
- [ ] `createTheme` utility
- [ ] Minimap component
- [ ] Controls component
- [ ] Background variants
- [ ] Status indicators (idle/running/success/error)
- [ ] Comprehensive documentation
- [ ] Unit tests (>80% coverage)

**Acceptance Criteria:**
- Both themes look professional
- Custom themes work
- All components documented
- Tests passing

### Phase 5: Platform Integration (Week 6)

**Goal:** Integrated into netpad-3 platform

**Deliverables:**
- [ ] Replace existing renderer in platform
- [ ] Verify visual parity
- [ ] Performance testing
- [ ] Publish v1.0.0 to NPM

**Acceptance Criteria:**
- Platform uses published package
- No visual regressions
- Performance equal or better

---

## 12. Testing Strategy

### 12.1 Unit Tests

| Component | Test Cases |
|-----------|------------|
| WorkflowRenderer | Renders with minimal props, handles empty workflow, respects dimensions |
| Each node type | Renders correctly, displays label, shows config preview |
| autoLayout | Handles linear workflow, handles branches, handles empty |
| createTheme | Merges with defaults, validates required fields |

### 12.2 Integration Tests

| Scenario | Test Case |
|----------|-----------|
| Complex workflow | Renders 20+ node workflow correctly |
| Theme switching | Switches between light/dark without errors |
| Auto-layout | Produces readable layout for branching workflow |
| Callbacks | onClick handlers fire with correct data |

### 12.3 Visual Regression

Use Storybook + Chromatic:
- Each node type in isolation
- Complete workflows (various sizes)
- Light and dark themes
- Different layout directions

---

## 13. Bundle Size Budget

| Component | Target Size (gzipped) |
|-----------|----------------------|
| Core (WorkflowRenderer) | <30KB |
| All nodes | <40KB |
| Edges | <5KB |
| Layout (Dagre) | <20KB |
| Themes | <5KB |
| **Total** | **<100KB** (excluding ReactFlow) |

Note: ReactFlow itself is ~150KB gzipped. Total with ReactFlow: ~250KB.

---

## 14. Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Bundle size | <100KB (excl. ReactFlow) | Bundlephobia |
| Node type coverage | 100% (29 types) | Manual audit |
| Render performance | <100ms for 50-node workflow | Performance test |
| Visual parity | 100% match with platform | Visual regression |
| Test coverage | >80% | Coverage report |
| TypeScript | 100% typed | No `any` types |

---

## 15. Open Questions

| # | Question | Options | Decision Needed By |
|---|----------|---------|-------------------|
| 1 | Include execution status display in v1? | Yes / No (add later) | Phase 1 start |
| 2 | Bundle ReactFlow or peer dependency? | Bundle / Peer dep | Phase 1 start |
| 3 | Support React 17? | Yes / React 18+ only | Phase 1 start |
| 4 | Include ELK layout as alternative to Dagre? | Yes / Dagre only | Phase 3 start |
| 5 | Minimap default on or off? | On / Off | Phase 4 |

---

## 16. Future Enhancements (Post-v1)

| Enhancement | Description | Priority |
|-------------|-------------|----------|
| **Execution visualization** | Animate data flow through workflow | High |
| **Error highlighting** | Show which node failed and why | High |
| **Custom node support** | Plugin system for custom node types | Medium |
| **ELK layout** | Alternative layout algorithm | Medium |
| **Export to image** | PNG/SVG export of workflow | Low |
| **Accessibility** | Keyboard navigation, screen readers | Medium |

---

## 17. Appendix

### A. Example Workflow Definitions

**Simple Linear Workflow:**

```typescript
const simpleWorkflow: WorkflowDefinition = {
  nodes: [
    { id: '1', type: 'form_trigger', data: { label: 'Contact Form' } },
    { id: '2', type: 'email_send', data: { label: 'Send Confirmation' } },
  ],
  edges: [
    { id: 'e1-2', source: '1', target: '2' },
  ],
};
```

**Branching Workflow:**

```typescript
const branchingWorkflow: WorkflowDefinition = {
  nodes: [
    { id: '1', type: 'form_trigger', data: { label: 'Support Request' } },
    { id: '2', type: 'filter', data: { label: 'Priority Check', config: { condition: 'priority === "high"' } } },
    { id: '3', type: 'email_send', data: { label: 'Alert IT Team' } },
    { id: '4', type: 'slack_send', data: { label: 'Post to #support' } },
    { id: '5', type: 'mongodb_insert', data: { label: 'Save to Tickets' } },
  ],
  edges: [
    { id: 'e1-2', source: '1', target: '2' },
    { id: 'e2-3', source: '2', target: '3', data: { label: 'High' } },
    { id: 'e2-4', source: '2', target: '4', data: { label: 'Normal' } },
    { id: 'e3-5', source: '3', target: '5' },
    { id: 'e4-5', source: '4', target: '5' },
  ],
};
```

### B. Node Component Template

```tsx
// src/nodes/actions/EmailSendNode.tsx
import { memo } from 'react';
import { NodeProps } from 'reactflow';
import { BaseNode } from '../BaseNode';
import { EmailIcon } from '../../icons';

interface EmailSendData {
  label: string;
  config?: {
    to?: string;
    subject?: string;
  };
}

export const EmailSendNode = memo(({ data, selected }: NodeProps<EmailSendData>) => {
  return (
    <BaseNode
      category="action"
      icon={<EmailIcon />}
      label={data.label}
      selected={selected}
      configPreview={data.config?.to}
      inputHandles={1}
      outputHandles={1}
    />
  );
});

EmailSendNode.displayName = 'EmailSendNode';
```

### C. Migration Guide from Platform

When migrating netpad-3 to use this package:

1. Install package: `npm install @netpad/workflow-renderer`
2. Import styles: `import '@netpad/workflow-renderer/styles.css'`
3. Replace custom node components with package nodes
4. Replace custom layout logic with `autoLayout`
5. Update theme to use package theme system
6. Remove deprecated custom code

---

## 18. Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | January 2025 | Michael | Initial specification |

---

## 19. Next Steps

1. Review with engineering team
2. Resolve open questions (Section 15)
3. Set up package in monorepo
4. Begin Phase 1 implementation
5. Create Storybook for development

---

*End of Specification*
