# Template Browser Component

## Technical Specification

**Version:** 1.0.0  
**Status:** Draft  
**Author:** Michael  
**Target:** Docusaurus documentation site (docs.netpad.io)

---

## 1. Overview

### 1.1 Purpose

The Template Browser component provides a developer-focused interface for discovering and exploring NetPad's 100+ templates directly within the documentation site. Unlike the full marketing experience at netpad.io/templates, this component emphasizes quick access to template configurations, code snippets, and technical details that developers need.

### 1.2 Goals

| Goal | Description | Success Metric |
|------|-------------|----------------|
| **Discovery** | Help developers find relevant templates quickly | <10 seconds to find a template by category or search |
| **Code-first** | Show TypeScript/JSON configs prominently | Config visible in 1 click |
| **Funnel to platform** | Drive traffic to netpad.io for full experience | Track clicks to "Try on NetPad" |
| **Stay current** | Always reflect latest @netpad/templates | Auto-sync with NPM package |

### 1.3 Non-Goals (v1)

- Full interactive form preview (use Live Form Preview component for that)
- Template customization or editing
- User accounts or saved favorites
- Template submission or contributions
- Replicating the full netpad.io/templates marketing experience

### 1.4 Relationship to Existing Systems

```
┌─────────────────────────────────────────────────────────────────┐
│                        @netpad/templates                        │
│                      (NPM Package - Source)                     │
└─────────────────────────────────┬───────────────────────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
                    ▼                           ▼
┌───────────────────────────┐   ┌───────────────────────────────┐
│   docs.netpad.io          │   │      netpad.io/templates      │
│   Template Browser        │   │      Full Gallery             │
│   (This Component)        │   │      (Existing)               │
│                           │   │                               │
│   • Developer-focused     │   │   • Marketing-focused         │
│   • Config/code emphasis  │   │   • Rich previews             │
│   • Lightweight           │   │   • Use cases & pain points   │
│   • Links to full exp.    │   │   • Conversational demo       │
└───────────────────────────┘   └───────────────────────────────┘
```

---

## 2. User Experience

### 2.1 Usage Contexts

| Context | Example | Expected Behavior |
|---------|---------|-------------------|
| **Browsing** | "What templates exist for healthcare?" | Filter by category, scan results |
| **Searching** | "Is there a patient intake template?" | Search by name/description |
| **Evaluating** | "What fields does this template have?" | Expand to see field list and config |
| **Using** | "I want to use this template" | Copy config or click through to netpad.io |

### 2.2 User Flow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Browse/   │────▶│   Filter/   │────▶│   Expand    │────▶│   Action    │
│   Land      │     │   Search    │     │   Template  │     │             │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
                                                                   │
                                              ┌────────────────────┼────────────────────┐
                                              │                    │                    │
                                              ▼                    ▼                    ▼
                                        ┌───────────┐        ┌───────────┐        ┌───────────┐
                                        │   Copy    │        │  View on  │        │   Use in  │
                                        │   Config  │        │  NetPad   │        │   Docs    │
                                        └───────────┘        └───────────┘        └───────────┘
```

### 2.3 Wireframe - Gallery View

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  Template Gallery                                                    106    │
│  Browse and use pre-built form templates                        templates  │
│                                                                             │
│  ┌───────────────────────────────────────┐  ┌─────────────┐  ┌───────────┐ │
│  │ 🔍 Search templates...                │  │ Category ▼  │  │ Sort by ▼ │ │
│  └───────────────────────────────────────┘  └─────────────┘  └───────────┘ │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ All (106)  Business (10)  Healthcare (7)  HR (8)  Finance (6)  ...  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ ┌─────────────────────────┐  ┌─────────────────────────┐            │   │
│  │ │ 📋 Contact Form         │  │ 📋 Lead Capture Form    │            │   │
│  │ │                         │  │                         │            │   │
│  │ │ Simple contact form for │  │ Capture and qualify     │            │   │
│  │ │ website inquiries       │  │ potential customers     │            │   │
│  │ │                         │  │                         │            │   │
│  │ │ ┌───────┐ ┌──────┐     │  │ ┌────────┐ ┌──────┐     │            │   │
│  │ │ │Simple │ │6 flds│     │  │ │Moderate│ │8 flds│     │            │   │
│  │ │ └───────┘ └──────┘     │  │ └────────┘ └──────┘     │            │   │
│  │ │                         │  │                         │            │   │
│  │ │ [View Config] [Try →]   │  │ [View Config] [Try →]   │            │   │
│  │ └─────────────────────────┘  └─────────────────────────┘            │   │
│  │                                                                      │   │
│  │ ┌─────────────────────────┐  ┌─────────────────────────┐            │   │
│  │ │ 📋 Patient Intake       │  │ 📋 Job Application      │            │   │
│  │ │ ...                     │  │ ...                     │            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Load More (showing 12 of 106)                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.4 Wireframe - Expanded Template Card

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │ 📋 Contact Form                                              [Collapse] │ │
│ │                                                                         │ │
│ │ Simple contact form for website inquiries                               │ │
│ │                                                                         │ │
│ │ ┌───────┐ ┌──────────────┐ ┌──────┐ ┌─────────────────┐                │ │
│ │ │Simple │ │Business/Sales│ │6 flds│ │~2 min to complete│                │ │
│ │ └───────┘ └──────────────┘ └──────┘ └─────────────────┘                │ │
│ │                                                                         │ │
│ │ ┌─────────────────────────────────────────────────────────────────────┐ │ │
│ │ │ Fields                                                              │ │ │
│ │ │                                                                     │ │ │
│ │ │  • First Name (string) - required                                   │ │ │
│ │ │  • Last Name (string) - required                                    │ │ │
│ │ │  • Email Address (email) - required                                 │ │ │
│ │ │  • Phone Number (phone)                                             │ │ │
│ │ │  • Inquiry Type (dropdown) - required                               │ │ │
│ │ │  • Your Message (long_text) - required                              │ │ │
│ │ └─────────────────────────────────────────────────────────────────────┘ │ │
│ │                                                                         │ │
│ │ ┌───────────────────────────────────────────────────────────────────┐   │ │
│ │ │ [TypeScript ▼]                                           [Copy]   │   │ │
│ │ ├───────────────────────────────────────────────────────────────────┤   │ │
│ │ │ ```typescript                                                     │   │ │
│ │ │ const contactForm: FormConfig = {                                 │   │ │
│ │ │   name: 'Contact Form',                                           │   │ │
│ │ │   fields: [                                                       │   │ │
│ │ │     {                                                             │   │ │
│ │ │       type: 'short_text',                                         │   │ │
│ │ │       path: 'firstName',                                          │   │ │
│ │ │       label: 'First Name',                                        │   │ │
│ │ │       required: true,                                             │   │ │
│ │ │     },                                                            │   │ │
│ │ │     // ... more fields                                            │   │ │
│ │ │   ]                                                               │   │ │
│ │ │ };                                                                │   │ │
│ │ │ ```                                                               │   │ │
│ │ └───────────────────────────────────────────────────────────────────┘   │ │
│ │                                                                         │ │
│ │ ┌─────────────────────┐  ┌──────────────────────────────────────────┐  │ │
│ │ │   Copy TypeScript   │  │      Try on NetPad ↗                    │  │ │
│ │ └─────────────────────┘  └──────────────────────────────────────────┘  │ │
│ └─────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Component API

### 3.1 Basic Usage

```jsx
import { TemplateBrowser } from '@site/components/TemplateBrowser';

// Full gallery - use on dedicated templates page
<TemplateBrowser />

// Filtered view - use in category-specific docs
<TemplateBrowser 
  category="healthcare"
  limit={6}
/>

// Single template embed - use in tutorial docs
<TemplateCard templateId="contact-form" />
```

### 3.2 TemplateBrowser Props

```typescript
interface TemplateBrowserProps {
  // === FILTERING ===
  
  /** Pre-filter to specific category */
  category?: TemplateCategory;
  
  /** Pre-filter to specific categories (multiple) */
  categories?: TemplateCategory[];
  
  /** Pre-filter by complexity */
  complexity?: 'simple' | 'moderate' | 'advanced';
  
  /** Pre-filter by form type */
  formType?: 'form' | 'survey' | 'wizard';
  
  /** Search query to pre-populate */
  initialSearch?: string;
  
  // === DISPLAY ===
  
  /** Number of templates to show initially */
  limit?: number;  // default: 12
  
  /** Show/hide the search bar */
  showSearch?: boolean;  // default: true
  
  /** Show/hide category filter tabs */
  showCategoryTabs?: boolean;  // default: true
  
  /** Show/hide the header */
  showHeader?: boolean;  // default: true
  
  /** Compact mode for embedding in docs */
  compact?: boolean;  // default: false
  
  /** Default expanded template (by ID) */
  defaultExpanded?: string;
  
  // === BEHAVIOR ===
  
  /** Base URL for "Try on NetPad" links */
  netpadBaseUrl?: string;  // default: 'https://www.netpad.io'
  
  /** Config format to show by default */
  defaultConfigFormat?: 'typescript' | 'json';  // default: 'typescript'
  
  /** Callback when template is selected/expanded */
  onTemplateSelect?: (templateId: string) => void;
  
  /** Callback when config is copied */
  onConfigCopy?: (templateId: string, format: string) => void;
}
```

### 3.3 TemplateCard Props (Standalone)

```typescript
interface TemplateCardProps {
  /** Template ID to display */
  templateId: string;
  
  /** Start expanded */
  defaultExpanded?: boolean;  // default: false
  
  /** Show the config section */
  showConfig?: boolean;  // default: true
  
  /** Config format */
  configFormat?: 'typescript' | 'json';  // default: 'typescript'
  
  /** Compact mode */
  compact?: boolean;  // default: false
}
```

### 3.4 Type Definitions

```typescript
type TemplateCategory = 
  | 'business'
  | 'hr'
  | 'healthcare'
  | 'finance'
  | 'education'
  | 'events'
  | 'feedback'
  | 'support'
  | 'ecommerce'
  | 'real-estate'
  | 'legal'
  | 'nonprofit'
  | 'marketing'
  | 'operations';

interface TemplateMetadata {
  id: string;
  name: string;
  description: string;
  category: TemplateCategory;
  complexity: 'simple' | 'moderate' | 'advanced';
  formType: 'form' | 'survey' | 'wizard';
  fieldCount: number;
  estimatedTime: string;  // e.g., "~2 min"
  featured?: boolean;
  tags?: string[];
}

interface TemplateField {
  path: string;
  label: string;
  type: string;
  required?: boolean;
}

interface Template extends TemplateMetadata {
  fields: TemplateField[];
  config: FormConfig;  // Full configuration object
}
```

### 3.5 Usage Examples

**Full gallery page:**

```jsx
// In docs/templates/index.mdx
import { TemplateBrowser } from '@site/components/TemplateBrowser';

# Template Gallery

Browse our collection of 100+ pre-built form templates.

<TemplateBrowser />
```

**Category-specific page:**

```jsx
// In docs/templates/healthcare.mdx
import { TemplateBrowser } from '@site/components/TemplateBrowser';

# Healthcare Templates

Templates designed for medical practices, clinics, and healthcare providers.

<TemplateBrowser 
  category="healthcare"
  showCategoryTabs={false}
  showHeader={false}
/>
```

**Embedded in tutorial:**

```jsx
// In docs/tutorials/build-contact-form.mdx
import { TemplateCard } from '@site/components/TemplateBrowser';

## Start with a Template

Instead of building from scratch, start with our Contact Form template:

<TemplateCard 
  templateId="contact-form" 
  defaultExpanded={true}
/>
```

**Compact list in sidebar-style:**

```jsx
// In docs/getting-started.mdx
import { TemplateBrowser } from '@site/components/TemplateBrowser';

## Popular Templates

<TemplateBrowser 
  limit={4}
  compact={true}
  showSearch={false}
  showCategoryTabs={false}
/>
```

---

## 4. Architecture

### 4.1 Component Structure

```
src/components/TemplateBrowser/
├── index.tsx                    # Main exports
├── TemplateBrowser.tsx          # Main container component
├── TemplateBrowserHeader.tsx    # Title, count, description
├── TemplateBrowserFilters.tsx   # Search, category tabs, dropdowns
├── TemplateGrid.tsx             # Grid layout for cards
├── TemplateCard.tsx             # Individual template card
├── TemplateCardExpanded.tsx     # Expanded view with fields + config
├── TemplateConfigViewer.tsx     # Syntax-highlighted config display
├── TemplateFieldList.tsx        # List of fields with types
├── hooks/
│   ├── useTemplates.ts          # Load and filter templates
│   ├── useTemplateSearch.ts     # Search logic
│   └── useConfigSerializer.ts   # JSON/TypeScript conversion
├── utils/
│   ├── templateLoader.ts        # Load from @netpad/templates
│   ├── configSerializer.ts      # Serialize to TS/JSON
│   └── categoryMeta.ts          # Category icons, colors, labels
├── styles/
│   └── TemplateBrowser.module.css
└── types.ts
```

### 4.2 Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                       @netpad/templates                         │
│                        (NPM Package)                            │
└─────────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                        templateLoader.ts                        │
│              (imports at build time, tree-shakes)               │
└─────────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                         useTemplates()                          │
│            (filtering, sorting, pagination state)               │
└─────────────────────────────────┬───────────────────────────────┘
                                  │
                    ┌─────────────┴─────────────┐
                    │                           │
                    ▼                           ▼
┌───────────────────────────┐   ┌───────────────────────────────┐
│   TemplateBrowserFilters  │   │        TemplateGrid           │
│   (search, categories)    │   │        (renders cards)        │
└───────────────────────────┘   └───────────────────────────────┘
                                              │
                                              ▼
                                ┌───────────────────────────────┐
                                │        TemplateCard           │
                                │   (collapsed or expanded)     │
                                └───────────────────────────────┘
                                              │
                                              ▼
                                ┌───────────────────────────────┐
                                │    TemplateConfigViewer       │
                                │   (syntax highlighted code)   │
                                └───────────────────────────────┘
```

### 4.3 Key Implementation Decisions

#### Decision 1: Data Source

**Recommendation:** Import directly from `@netpad/templates` at build time

```typescript
// templateLoader.ts
import { templates, categories } from '@netpad/templates';

export function getAllTemplates(): Template[] {
  return templates;
}

export function getTemplateById(id: string): Template | undefined {
  return templates.find(t => t.id === id);
}

export function getTemplatesByCategory(category: TemplateCategory): Template[] {
  return templates.filter(t => t.category === category);
}
```

**Why:**
- Templates are static at build time (no runtime API calls)
- Automatic updates when @netpad/templates is updated
- Tree-shaking removes unused templates in filtered views
- No CORS, auth, or network concerns

#### Decision 2: Search Implementation

**Recommendation:** Client-side fuzzy search with Fuse.js

```typescript
// useTemplateSearch.ts
import Fuse from 'fuse.js';

const fuse = new Fuse(templates, {
  keys: [
    { name: 'name', weight: 2 },
    { name: 'description', weight: 1 },
    { name: 'tags', weight: 1.5 },
    { name: 'category', weight: 0.5 },
  ],
  threshold: 0.3,
});

export function searchTemplates(query: string): Template[] {
  if (!query.trim()) return templates;
  return fuse.search(query).map(result => result.item);
}
```

**Why:**
- Fast client-side search (no network latency)
- Fuzzy matching handles typos
- Lightweight (~5KB gzipped)

#### Decision 3: Config Serialization

**Recommendation:** Pre-generate both JSON and TypeScript at build time

```typescript
// configSerializer.ts
export function toTypeScript(template: Template): string {
  const config = template.config;
  return `const ${camelCase(template.name)}Config: FormConfig = ${formatObject(config, 'typescript')};`;
}

export function toJSON(template: Template): string {
  return JSON.stringify(template.config, null, 2);
}
```

**Why:**
- No runtime serialization overhead
- TypeScript output can include proper typing
- Consistent formatting

#### Decision 4: Styling Approach

**Recommendation:** CSS Modules with Docusaurus theme tokens

```css
/* TemplateBrowser.module.css */
.card {
  background: var(--ifm-card-background-color);
  border: 1px solid var(--ifm-color-emphasis-300);
  border-radius: var(--ifm-card-border-radius);
}

.card:hover {
  border-color: var(--ifm-color-primary);
}

/* Dark mode automatic via Docusaurus */
```

**Why:**
- Respects Docusaurus light/dark theme automatically
- No additional styling dependencies
- Consistent with rest of docs site

---

## 5. Implementation Phases

### Phase 1: Core Browser (Week 1)

**Goal:** Functional template browser with search and filtering

**Deliverables:**
- [ ] templateLoader.ts - import from @netpad/templates
- [ ] TemplateBrowser.tsx - main container
- [ ] TemplateBrowserFilters.tsx - search + category tabs
- [ ] TemplateGrid.tsx - responsive grid layout
- [ ] TemplateCard.tsx - collapsed card view
- [ ] useTemplates.ts - filtering and pagination
- [ ] Basic CSS styling

**Acceptance Criteria:**
- Can browse all templates
- Search works
- Category filtering works
- Cards show name, description, complexity, field count
- Responsive grid layout

### Phase 2: Expanded View & Config (Week 2)

**Goal:** Template detail view with config export

**Deliverables:**
- [ ] TemplateCardExpanded.tsx - expanded card state
- [ ] TemplateFieldList.tsx - list fields with types
- [ ] TemplateConfigViewer.tsx - syntax highlighted code
- [ ] configSerializer.ts - JSON/TypeScript output
- [ ] useConfigSerializer.ts - format switching
- [ ] Copy to clipboard functionality
- [ ] "Try on NetPad" link

**Acceptance Criteria:**
- Click card to expand
- See list of fields with types and required status
- Toggle between TypeScript and JSON
- Copy button works
- External link to netpad.io/templates/{id}

### Phase 3: Polish & Integration (Week 3)

**Goal:** Production-ready with docs integration

**Deliverables:**
- [ ] TemplateCard standalone component
- [ ] Compact mode styling
- [ ] Category metadata (icons, colors, descriptions)
- [ ] "Load more" pagination
- [ ] URL query params for deep linking (?category=healthcare&search=patient)
- [ ] Analytics events (template view, config copy, external click)
- [ ] Integration into docs pages

**Acceptance Criteria:**
- TemplateCard works standalone in MDX
- Compact mode suitable for embedding
- Deep links work for sharing
- Integrated into at least 3 docs pages

---

## 6. Category Metadata

```typescript
// categoryMeta.ts
export const categoryMeta: Record<TemplateCategory, CategoryMeta> = {
  business: {
    label: 'Business & Sales',
    icon: '💼',
    color: '#10B981',  // green
    description: 'Contact forms, lead capture, quotes',
  },
  healthcare: {
    label: 'Healthcare & Wellness',
    icon: '🏥',
    color: '#3B82F6',  // blue
    description: 'Patient intake, medical history, appointments',
  },
  hr: {
    label: 'HR & Recruitment',
    icon: '👥',
    color: '#8B5CF6',  // purple
    description: 'Job applications, onboarding, time off',
  },
  finance: {
    label: 'Finance & Accounting',
    icon: '💰',
    color: '#F59E0B',  // amber
    description: 'Expense reports, invoices, budgets',
  },
  education: {
    label: 'Education & Training',
    icon: '📚',
    color: '#EC4899',  // pink
    description: 'Course enrollment, evaluations, certifications',
  },
  events: {
    label: 'Events & Registration',
    icon: '🎫',
    color: '#06B6D4',  // cyan
    description: 'Event registration, RSVPs, ticketing',
  },
  feedback: {
    label: 'Feedback & Surveys',
    icon: '📊',
    color: '#84CC16',  // lime
    description: 'Customer satisfaction, NPS, reviews',
  },
  support: {
    label: 'Customer Service',
    icon: '🎧',
    color: '#F97316',  // orange
    description: 'Help desk, bug reports, feature requests',
  },
  ecommerce: {
    label: 'E-commerce',
    icon: '🛒',
    color: '#EF4444',  // red
    description: 'Order forms, product inquiries, returns',
  },
  'real-estate': {
    label: 'Real Estate & Property',
    icon: '🏠',
    color: '#14B8A6',  // teal
    description: 'Property inquiries, rental applications, maintenance',
  },
  legal: {
    label: 'Legal & Compliance',
    icon: '⚖️',
    color: '#6366F1',  // indigo
    description: 'NDAs, contracts, compliance forms',
  },
  nonprofit: {
    label: 'Nonprofit & Donations',
    icon: '❤️',
    color: '#F43F5E',  // rose
    description: 'Donation forms, volunteer signup, grants',
  },
  marketing: {
    label: 'Marketing & Research',
    icon: '📣',
    color: '#A855F7',  // fuchsia
    description: 'Lead magnets, research surveys, campaign forms',
  },
  operations: {
    label: 'Operations & IT',
    icon: '⚙️',
    color: '#64748B',  // slate
    description: 'IT requests, asset tracking, incident reports',
  },
};
```

---

## 7. Dependencies

### 7.1 NPM Packages

```json
{
  "dependencies": {
    "@netpad/templates": "^1.x",
    "fuse.js": "^7.x",
    "prism-react-renderer": "^2.x"
  }
}
```

### 7.2 Docusaurus Integration

No special configuration needed. Component uses standard React and CSS Modules which Docusaurus supports out of the box.

Optional: Add to `docusaurus.config.js` for analytics:

```javascript
module.exports = {
  // ...
  scripts: [
    {
      src: '/js/template-analytics.js',
      async: true,
    },
  ],
};
```

---

## 8. Analytics Events

Track these events for product insights:

| Event | Payload | Purpose |
|-------|---------|---------|
| `template_view` | `{ templateId, source }` | Which templates are popular |
| `template_expand` | `{ templateId }` | Engagement depth |
| `template_config_copy` | `{ templateId, format }` | Conversion to usage |
| `template_try_click` | `{ templateId }` | Funnel to platform |
| `template_search` | `{ query, resultCount }` | Search behavior |
| `template_filter` | `{ category, complexity }` | Discovery patterns |

---

## 9. Testing Strategy

### 9.1 Unit Tests

| Component | Test Cases |
|-----------|------------|
| templateLoader | Loads all templates, finds by ID, filters by category |
| useTemplateSearch | Empty query returns all, fuzzy matching works, handles special chars |
| configSerializer | Valid TypeScript output, valid JSON output, escapes special chars |
| TemplateCard | Renders collapsed, expands on click, shows correct metadata |

### 9.2 Integration Tests

| Scenario | Test Case |
|----------|-----------|
| Browse | Load page, see template count, cards render |
| Search | Type query, results filter, clear returns all |
| Filter | Click category tab, grid updates, count updates |
| Expand | Click card, fields list shows, config shows |
| Copy | Click copy, clipboard contains valid config |
| External link | "Try on NetPad" opens correct URL |

### 9.3 Visual Regression

- Light and dark theme
- Various screen sizes (mobile, tablet, desktop)
- Empty state (no search results)
- Loading state (if applicable)

---

## 10. Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Bundle size impact | <50KB gzipped | Webpack analyzer |
| Time to interactive | <500ms | Lighthouse |
| Template coverage | 100% of @netpad/templates | Automated check |
| Search response time | <100ms | Performance test |
| Click-through to netpad.io | Track baseline, improve | Analytics |
| Config copy rate | Track baseline | Analytics |

---

## 11. Open Questions

| # | Question | Options | Decision Needed By |
|---|----------|---------|-------------------|
| 1 | Should we show template screenshots/thumbnails? | Yes (more visual) / No (faster, simpler) | Phase 1 start |
| 2 | Include complexity filter dropdown or just category tabs? | Both / Category only | Phase 1 start |
| 3 | How many templates to show before "Load More"? | 12 / 24 / All | Phase 1 |
| 4 | Should expanded view be inline or modal? | Inline (current wireframe) / Modal | Phase 2 start |
| 5 | Deep linking - query params or hash? | Query params / Hash / None | Phase 3 |

---

## 12. Future Enhancements (Post-v1)

| Enhancement | Description | Priority |
|-------------|-------------|----------|
| **Thumbnail previews** | Show form screenshot in card | Medium |
| **Live preview integration** | Use LiveFormPreview component in expanded view | Medium |
| **Favorites/bookmarks** | Local storage based favorites | Low |
| **Compare templates** | Side-by-side comparison view | Low |
| **Template diff** | Show what changed between versions | Low |
| **AI recommendations** | "Based on your use case..." | Future |

---

## 13. Appendix

### A. Sample Template Data Structure

From `@netpad/templates`:

```typescript
// @netpad/templates/src/forms/contact-form.ts
export const contactForm: Template = {
  id: 'contact-form',
  name: 'Contact Form',
  description: 'Simple contact form for website inquiries',
  category: 'business',
  complexity: 'simple',
  formType: 'form',
  fieldCount: 6,
  estimatedTime: '~2 min',
  featured: true,
  tags: ['contact', 'lead', 'inquiry', 'website'],
  fields: [
    { path: 'firstName', label: 'First Name', type: 'short_text', required: true },
    { path: 'lastName', label: 'Last Name', type: 'short_text', required: true },
    { path: 'email', label: 'Email Address', type: 'email', required: true },
    { path: 'phone', label: 'Phone Number', type: 'phone', required: false },
    { path: 'inquiryType', label: 'Inquiry Type', type: 'dropdown', required: true },
    { path: 'message', label: 'Your Message', type: 'long_text', required: true },
  ],
  config: {
    // Full FormConfig object
    name: 'Contact Form',
    fields: [
      {
        type: 'short_text',
        path: 'firstName',
        label: 'First Name',
        required: true,
        placeholder: 'John',
        width: 'half',
      },
      // ... complete field configs
    ],
    settings: {
      submitButtonText: 'Send Message',
      successMessage: 'Thank you for your inquiry!',
    },
  },
};
```

### B. URL Structure for Deep Linking

```
/docs/templates                           # Full gallery
/docs/templates?category=healthcare       # Filtered by category
/docs/templates?search=patient            # Search results
/docs/templates?id=patient-intake         # Specific template expanded
/docs/templates/healthcare                # Category page (alternative)
```

### C. External Links Format

```
Try on NetPad: https://www.netpad.io/templates/{templateId}
Full Gallery:  https://www.netpad.io/templates
Category:      https://www.netpad.io/templates?category={category}
```

---

## 14. Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | January 2025 | Michael | Initial specification |

---

## 15. Next Steps

1. Review with engineering team
2. Resolve open questions (Section 11)
3. Confirm @netpad/templates package structure matches expected interface
4. Create GitHub issues for Phase 1
5. Begin implementation

---

*End of Specification*
